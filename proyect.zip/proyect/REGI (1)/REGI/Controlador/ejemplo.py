from Modelos.Estudiante import Estudiante
from Repositorios.RepositorioEstudiantes import Estudiante
#class ControladorEstudiante():




#  def index(self):
   #     print("Listar todos los Usuarios")
    #    unUsuario = {
     #       "_id": "abc123",
      #      "cedula": "123",
       #     "nombre": "Juan",
        #    "apellido": "Perez",
         #   "Rol":"Ciudadano"

      #  }
       # return [unUsuario]

  #  def create(self, infoUsuarios):
  #      print("Crear un Usuario")
   #     elUsuario=Usuarios(infoUsuarios)
     #   return elUsuario ._dict_

#    def show(self, id):
#        print("Mostrando un Usuario con id ", id)
 #       elUsuario = {
 #            "_id": id,
 #            "cedula": "123",
 #            "nombre": "Juan",
 #            "apellido": "Perez",
 #            "Rol": "Ciudadano"
 #       }
 #       return elUsuario

 #   def update(self, id, infoUsuarios):
 #       print("Actualizando Usuario con id ", id)
 #       elUsuario= Usuarios(infoUsuarios)
 #       return elUsuario._dict_

 #   def delete(self, id):
 #       print("Eliminando Usuario con id ", id)
 #       return {"deleted_count":1}