from Repositorios.InterfaceRepositorio import InterfaceRepositorio
from Modelos.Mesas import Mesas


class RepositorioMesas(InterfaceRepositorio[Mesas]):
    pass
