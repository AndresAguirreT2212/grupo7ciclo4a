from Repositorios.InterfaceRepositorio import InterfaceRepositorio
from Modelos.Candidatos import Candidatos


class RepositorioCandidatos(InterfaceRepositorio[Candidatos]):
    pass
