from Repositorios.InterfaceRepositorio import InterfaceRepositorio
from Modelos.Partidos import Partidos


class RepositorioPartidos(InterfaceRepositorio[Partidos]):
    pass
