from Modelos.AbstractModelo import AbstractModelo
class Partidos(AbstractModelo):
        pass