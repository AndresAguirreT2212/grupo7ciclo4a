from Modelos.AbstractModelo import AbstractModelo
class Resultados(AbstractModelo):
        pass