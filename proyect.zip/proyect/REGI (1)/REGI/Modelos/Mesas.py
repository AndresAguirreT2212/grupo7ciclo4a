from Modelos.AbstractModelo import AbstractModelo
class Mesas(AbstractModelo):
        pass