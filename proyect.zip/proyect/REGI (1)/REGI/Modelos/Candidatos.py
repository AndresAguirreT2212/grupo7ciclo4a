from Modelos.AbstractModelo import AbstractModelo
class Candidatos(AbstractModelo):
        pass

